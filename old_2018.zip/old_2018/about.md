---
layout: page
title: About Me
permalink: /about/
---

![Baur](/assets/baur.png "Baur Urazalinov")

Welcome to my blog!
My name is Baur Urazalinov. <br>

I'm a software developer, data analyst, happy father, and lucky husband. <br>
